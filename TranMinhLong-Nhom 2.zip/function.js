function enterName(first, second) {
    console.log("Ten sinh vien " + first);
}

enterName('Long', 'Minh');

