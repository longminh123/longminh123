//Obj
var tencty = 'Cybozu';
var luong = '2250';

var abc = {
    cty: tencty,
    luong: luong,
};
console.log(abc);
//JSON
console.log(JSON.stringify( 'long'));
console.log(JSON.parse('123'));
