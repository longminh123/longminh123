//forloop

//for (var i = 5; i<=20; i++){
   // console.log(i)
//}
// 
var myarray = [
    'cy',
    'bo',
    'zu',
    'long',
    'minh'
];
var arrayLength = myarray.length;

for (var i =0; i < arrayLength; i++){
    console.log(myarray[i])
}