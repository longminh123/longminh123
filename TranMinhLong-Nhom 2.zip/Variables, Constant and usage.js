var Name = "long"
var age = 22

if (age < 30) {
    var Name = "em long"
} 

console.log(Name) 

//let
let Name1 ='long1'
let newage = 22
 
if (newage < 30) {
    //block
    let Name1 = "em long"
    console.log(Name1)
} 
console.log (Name1)

//const
const car = {type:"Iphone", model:"13 series", color:"white"};
car.color = "red";
car.owner = "em long";
console.log(car)
