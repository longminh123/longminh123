/**
 * if-else
 */

/** tất cả là false
 * 0
 * false
 * null
 * ""-''
 * undefined
 * NaN
 */

var ten = 3 > 5

if (ten){
    console.log ("thanh cong")
}else {
    console.log('that bai')
}
//lệnh rẽ nhánh if
var thu = 2 ;
if(thu ===2){
    console.log('Hom nay la thu 2')
}else if (thu == 3){
    console.log('Hom nay la thu 3')
}else{
    console.log('Khum biet')
}